import { Component, OnInit } from '@angular/core';
import {AppComponent} from '../app.component';
import { ActivatedRoute } from '@angular/router';
@Component({
  selector: 'app-welcome',
  templateUrl: './welcome.component.html',
  styleUrls: ['./welcome.component.css']
})

// export is a kind of the access specifier 
export class WelcomeComponent implements OnInit {
 
  // member variables 
  message = 'Welcome Yash';
  name = '';

  // similar to public addition() {constructor in java}
  constructor(private route: ActivatedRoute) { }

  // similar to a method name (void init)
  // if there is any thing after : after method name then it is the return type
  ngOnInit(){
    console.log(this.message)
    //console.log(this.route.snapshot.params['name'])
    this.name = this.route.snapshot.params['name'];
  }

}
