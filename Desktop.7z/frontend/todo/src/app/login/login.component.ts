import { Component, OnInit } from '@angular/core';
import {Router} from '@angular/router';
import { from } from 'rxjs';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  constructor(private router:Router) { }
 
  username:String;
  password ;
  errorMessage = 'Invalid Credentials';
  invalidLogin = false;

  ngOnInit() {

  }
handleLogin() {
    
    if (this.username === 'yash' && this.password === '1234') {
    
      // Redirect to the welcome Page using router instance
      this.router.navigate(['welcome',this.username]);
      this.invalidLogin = false;
    }
    else {
      this.invalidLogin = true ;
    }
  }

}
