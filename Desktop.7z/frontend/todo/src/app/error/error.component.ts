import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-error',
  templateUrl: './error.component.html',
  styleUrls: ['./error.component.css']
})
export class ErrorComponent implements OnInit {

  errorMessage ='You Are Trying out Something new So we Regret for the same Please select from the availabe menu :-D' ;
  constructor() { }

  ngOnInit() {
  }

}
